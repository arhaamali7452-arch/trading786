Admin.find_or_create_by!(username: "admin") do |admin|
  admin.password = "ChangeMe123!"
end

[
  ["Starter", 450], ["Basic", 1000], ["Standard", 5000],
  ["Premium", 25000], ["Pro", 100000], ["Elite", 250000]
].each do |name, amount|
  Package.find_or_create_by!(name: name) { |p| p.amount = amount; p.active = true }
end
