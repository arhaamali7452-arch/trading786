class CreateUsers < ActiveRecord::Migration[7.1]
  def change
    create_table :users do |t|
      t.string :name, null: false
      t.string :email, null: false
      t.string :referral_code
      t.string :status, null: false, default: "Active"
      t.timestamps
    end
    add_index :users, :email, unique: true
    add_index :users, :referral_code, unique: true
  end
end
