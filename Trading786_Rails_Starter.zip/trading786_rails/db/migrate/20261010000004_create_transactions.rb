class CreateTransactions < ActiveRecord::Migration[7.1]
  def change
    create_table :transactions do |t|
      t.references :user, foreign_key: true, null: true
      t.string :kind, null: false
      t.decimal :amount, precision: 12, scale: 2, null: false
      t.string :status, null: false, default: "Pending"
      t.string :reference
      t.timestamps
    end
  end
end
