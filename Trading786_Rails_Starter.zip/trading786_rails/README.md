# Trading 786 — Ruby on Rails Admin Starter

یہ Rails starter project admin login، dashboard، users، packages، demo transactions،
referral overview اور reports کے لیے ہے۔ ادائیگی صرف demo record ہے؛ یہ Easypaisa سے رابطہ
نہیں کرتا اور حقیقی رقم منتقل نہیں کرتا۔

## ضروری چیزیں
- Ruby 3.2+
- Bundler
- Rails 7.1
- SQLite3

## چلانے کا طریقہ
یہ ایک Rails starter scaffold ہے۔ پہلے Rails app بنائیں اور پھر اس ZIP کے `app`، `config`،
`db` اور `Gemfile` والے حصے اپنی نئی app میں رکھیں:
```bash
gem install rails -v "~> 7.1.5"
rails new trading786 --database=sqlite3
cd trading786
# ZIP کے project files اپنی نئی app میں merge کریں
bundle install
bin/rails db:prepare
bin/rails db:seed
bin/rails server
```
پھر http://localhost:3000 کھولیں۔

## مقامی demo admin
- Username: `admin`
- Password: `ChangeMe123!`

یہ صرف local development کے لیے ہے؛ استعمال سے پہلے password بدلیں۔ یہ starter production-ready
نہیں ہے۔ Easypaisa PIN، OTP یا password کبھی اس app میں درج نہ کریں۔
