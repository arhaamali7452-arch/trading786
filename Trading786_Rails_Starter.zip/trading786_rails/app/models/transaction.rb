class Transaction < ApplicationRecord
  belongs_to :user, optional: true
  KINDS = ["Demo Deposit", "Demo Withdrawal", "Demo Adjustment"].freeze
  STATUSES = ["Pending", "Approved", "Rejected"].freeze
  validates :kind, inclusion: { in: KINDS }
  validates :status, inclusion: { in: STATUSES }
  validates :amount, numericality: { greater_than: 0, less_than_or_equal_to: 250000 }
end
