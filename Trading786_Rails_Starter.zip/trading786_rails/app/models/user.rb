class User < ApplicationRecord
  has_many :transactions, dependent: :nullify
  STATUSES = ["Active", "Blocked"].freeze
  validates :name, presence: true
  validates :email, presence: true, uniqueness: true
  validates :referral_code, uniqueness: true, allow_nil: true
  validates :status, inclusion: { in: STATUSES }
end
