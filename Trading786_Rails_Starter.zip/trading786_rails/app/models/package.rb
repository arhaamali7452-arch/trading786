class Package < ApplicationRecord
  validates :name, presence: true
  validates :amount, numericality: { greater_than_or_equal_to: 450, less_than_or_equal_to: 250000 }
end
