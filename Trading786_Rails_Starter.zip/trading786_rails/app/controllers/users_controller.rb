class UsersController < ApplicationController
  before_action :require_admin!
  before_action :set_user, only: [:edit, :update, :destroy]
  def index
    @users = User.order(created_at: :desc)
    @user = User.new
  end
  def create
    @user = User.new(user_params)
    @user.referral_code = "T786#{SecureRandom.hex(3).upcase}"
    if @user.save
      redirect_to users_path, notice: "User add ہوگیا۔"
    else
      @users = User.order(created_at: :desc)
      render :index, status: :unprocessable_entity
    end
  end
  def edit; end
  def update
    if @user.update(user_params)
      redirect_to users_path, notice: "User update ہوگیا۔"
    else
      render :edit, status: :unprocessable_entity
    end
  end
  def destroy
    @user.destroy
    redirect_to users_path, notice: "User delete ہوگیا۔"
  end
  private
  def set_user
    @user = User.find(params[:id])
  end
  def user_params
    params.require(:user).permit(:name, :email, :status)
  end
end
