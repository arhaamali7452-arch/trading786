class ReportsController < ApplicationController
  before_action :require_admin!
  def index
    @users_count = User.count
    @packages_count = Package.count
    @transactions_count = Transaction.count
    @pending_count = Transaction.where(status: "Pending").count
  end
end
