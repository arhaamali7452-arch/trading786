class PackagesController < ApplicationController
  before_action :require_admin!
  before_action :set_package, only: [:edit, :update, :destroy]
  def index
    @packages = Package.order(:amount)
    @package = Package.new
  end
  def create
    @package = Package.new(package_params)
    if @package.save
      redirect_to packages_path, notice: "Package add ہوگیا۔"
    else
      @packages = Package.order(:amount)
      render :index, status: :unprocessable_entity
    end
  end
  def edit; end
  def update
    if @package.update(package_params)
      redirect_to packages_path, notice: "Package update ہوگیا۔"
    else
      render :edit, status: :unprocessable_entity
    end
  end
  def destroy
    @package.destroy
    redirect_to packages_path, notice: "Package delete ہوگیا۔"
  end
  private
  def set_package
    @package = Package.find(params[:id])
  end
  def package_params
    params.require(:package).permit(:name, :amount, :active)
  end
end
