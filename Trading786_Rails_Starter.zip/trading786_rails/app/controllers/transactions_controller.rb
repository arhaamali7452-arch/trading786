class TransactionsController < ApplicationController
  before_action :require_admin!
  before_action :set_transaction, only: [:edit, :update, :destroy]
  def index
    @transactions = Transaction.includes(:user).order(created_at: :desc)
    @transaction = Transaction.new
    @users = User.order(:name)
  end
  def create
    @transaction = Transaction.new(transaction_params)
    @transaction.status = "Pending"
    if @transaction.save
      redirect_to transactions_path, notice: "Demo record بن گیا؛ کوئی رقم منتقل نہیں ہوئی۔"
    else
      @transactions = Transaction.includes(:user).order(created_at: :desc)
      @users = User.order(:name)
      render :index, status: :unprocessable_entity
    end
  end
  def edit
    @users = User.order(:name)
  end
  def update
    if @transaction.update(transaction_params)
      redirect_to transactions_path, notice: "Demo record update ہوگیا؛ کوئی رقم منتقل نہیں ہوئی۔"
    else
      @users = User.order(:name)
      render :edit, status: :unprocessable_entity
    end
  end
  def destroy
    @transaction.destroy
    redirect_to transactions_path, notice: "Record delete ہوگیا۔"
  end
  private
  def set_transaction
    @transaction = Transaction.find(params[:id])
  end
  def transaction_params
    params.require(:transaction).permit(:user_id, :kind, :amount, :status, :reference)
  end
end
