class DashboardController < ApplicationController
  before_action :require_admin!
  def index
    @users_count = User.count
    @packages_count = Package.where(active: true).count
    @transactions_count = Transaction.count
    @pending_count = Transaction.where(status: "Pending").count
    @recent_transactions = Transaction.includes(:user).order(created_at: :desc).limit(8)
  end
end
