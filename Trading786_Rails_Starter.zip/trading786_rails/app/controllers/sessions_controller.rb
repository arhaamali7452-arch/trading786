class SessionsController < ApplicationController
  def new
    redirect_to root_path if logged_in?
  end
  def create
    admin = Admin.find_by(username: params[:username].to_s.strip)
    if admin&.authenticate(params[:password].to_s)
      reset_session
      session[:admin_id] = admin.id
      redirect_to root_path, notice: "Login کامیاب ہوگیا۔"
    else
      flash.now[:alert] = "Username یا password غلط ہے۔"
      render :new, status: :unprocessable_entity
    end
  end
  def destroy
    reset_session
    redirect_to login_path, notice: "آپ logout ہوگئے۔"
  end
end
