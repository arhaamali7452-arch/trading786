class ApplicationController < ActionController::Base
  helper_method :current_admin, :logged_in?
  private
  def current_admin
    @current_admin ||= Admin.find_by(id: session[:admin_id])
  end
  def logged_in?
    current_admin.present?
  end
  def require_admin!
    redirect_to login_path, alert: "براہ کرم پہلے login کریں۔" unless logged_in?
  end
end
