class ReferralsController < ApplicationController
  before_action :require_admin!
  def index
    @users = User.order(created_at: :desc)
  end
end
