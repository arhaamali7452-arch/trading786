Rails.application.routes.draw do
  root "dashboard#index"
  get "/login", to: "sessions#new"
  post "/login", to: "sessions#create"
  delete "/logout", to: "sessions#destroy"
  resources :users, except: [:show]
  resources :packages, except: [:show]
  resources :transactions, except: [:show]
  get "/referrals", to: "referrals#index", as: :referrals
  get "/reports", to: "reports#index", as: :reports
end
